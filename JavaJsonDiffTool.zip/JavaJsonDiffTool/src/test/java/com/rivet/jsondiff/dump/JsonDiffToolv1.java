package com.rivet.jsondiff.dump;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONObjectOrdered;
import org.json.simple.JSONValue;
import org.json.simple.parser.ContainerFactory;
import org.json.simple.parser.ParseException;

import com.rivet.jsondiff.util.JsonUtil;

//import javax.script.ScriptEngineManager;

public class JsonDiffToolv1 {
	
	// compare json files and store the differences result
	public static void compareJsonsAndStoreDiffs(JSONObject leftJson,JSONObject rightJson,List<String> leftKeyList,List<String> rightKeyList) {
		BufferedWriter bw = null;
		
		try {			
			// String timeStamp = new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
			String outputFile = "C:\\Users\\venky\\Desktop\\rivetlabs\\json-diff\\ResultJsonDiffs.json";
			bw = new BufferedWriter(new FileWriter(outputFile));			
			
			// create output objects
			JSONObjectOrdered outputJson = new JSONObjectOrdered();
			JSONObjectOrdered additionsJson = new JSONObjectOrdered();
			JSONObjectOrdered modificationsJson = new JSONObjectOrdered();
			JSONArray deletionsJsonArray = new JSONArray();
			
			// compare jsons and find differences
			// take json entry from right json and compare with left json
			for(String rightTopLevelKey:rightKeyList) {
				
				// additions - present in right missing in left
				if(!leftJson.containsKey(rightTopLevelKey)) {
					addToAdditions(rightJson,additionsJson,rightTopLevelKey);
				}
				
				// modifications
				
				// deletions
				
			}
			
			// write formatted json output to result file
			String unformattedJsonString = additionsJson.toJSONString();
			bw.write(JsonUtil.prettyPrintJSON(unformattedJsonString));
			bw.flush();
			
			
			/*
			//test			
			JSONObjectOrdered obj = new JSONObjectOrdered();			
			JSONObjectOrdered map1 = new JSONObjectOrdered();
			map1.put("1one", "1");
			map1.put("2two", 2);
			map1.put("3three", "3");
			map1.put("4zero", 0);			
			JSONArray jarr1 = new JSONArray();
			jarr1.add("1"); jarr1.add("2"); jarr1.add(3);
			jarr1.add("4"); jarr1.add(5.123);
			
			obj.put("Map 1", map1);
			obj.put("Array 1", jarr1);
			obj.put("String 1", "Str");
			obj.put("Int 1", 123);
			obj.put("Float 1", 10.157f);
			
			System.out.println("leftJson: "+leftJson);
			System.out.println("rightJson: "+rightJson);
			System.out.println("leftList: "+leftList);
			System.out.println("rightList: "+rightList);
			System.out.println("obj: "+obj);
			
			//obj.writeJSONString(bw);
			//leftJson.writeJSONString(bw);
			//fw.write(obj.toJSONString());
			
			String unformattedJsonString = obj.toJSONString();
			bw.write(JsonUtil.prettyPrintJSON(unformattedJsonString));
			bw.flush();
			
			output:
			leftJson: {"bar1":2,"foo11":{"bar":["bat","baz"]},"test1":{"a":1}}
			rightJson: {"bar2":3,"test2":{"a":2},"foo22":{"bar":["baz"]}}
			leftList: [foo11, test1, bar1]
			rightList: [foo22, test2, bar2]
			obj: {"Map 1":{"1one":"1","2two":2,"3three":"3","4zero":0},"Array 1":["1","2",3,"4",5.123],"String 1":"Str","Int 1":123,"Float 1":10.157}
			total time taken: 47ms
			
			leftJson: {"bar1":2,"foo11":{"bar":["bat","baz"]},"test1":{"a":1}}
			rightJson: {"bar2":3,"test2":{"a":2},"foo22":{"bar":["baz"]}}
			leftList: [foo11, test1, bar1]
			rightList: [foo22, test2, bar2]
			obj: {"Map 1":{"1one":"1","2two":2,"3three":"3","4zero":0},"Array 1":["1","2",3,"4",5.123],"String 1":"Str","Int 1":123,"Float 1":10.157}
			total time taken: 51ms

			*/
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
//		} catch (ParseException e) {
//			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// release resources
			try {
				if(bw != null)
					bw.close();
			}catch (Exception e) {
				e.printStackTrace();
			}			
		}		
	}
	
	// json entries present in right json but missing in left json
	// those json entries add to additions
	public static void addToAdditions(JSONObject rightJson,JSONObjectOrdered additionsJson,String rightTopLevelKey) {
		
	}
}

