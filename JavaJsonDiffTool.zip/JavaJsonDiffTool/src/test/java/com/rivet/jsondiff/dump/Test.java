package com.rivet.jsondiff.dump;

public class Test {

	public static void main(String[] args) {
		String s1="12",s2="20";
		int i=5;
		String v=s1+"."+i;
		//System.out.println(v);
		//double d1=40.12,d2=40.12;
		Double d1=40.119,d2=40.119;
		//System.out.println(s1.compareTo(s2));
		System.out.println(d1.equals(d2));

	}

}
