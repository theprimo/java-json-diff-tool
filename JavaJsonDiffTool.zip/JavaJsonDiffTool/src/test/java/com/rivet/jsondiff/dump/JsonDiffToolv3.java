package com.rivet.jsondiff.dump;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONAware;
import org.json.simple.JSONObjectOrdered;
import org.json.simple.JSONStreamAware;

import com.rivet.jsondiff.util.JsonUtil;


/**
 * this class contains methods for json files comparison & diffs
 * each json entry or object is represented as a <key,value> pair
 * for making things easier, we're converting input json files into ordered maps
 * json object is equivalent to java map and json array is equivalent to java collection,list
 * 
 * all json keys are string types
 * json value types are of 3 categories
 * 1. Map
 * 2. Collection or list or Array
 * 3. Literal - String, Integer, Number, Float, Double, Boolean, Character
 * 1 & 2 category types to be handled with care due to nested structure
 * 
 * as of now, nested lists, we're not handling  ex: list inside list
 * we're handling list inside map & nested maps  ex: map inside map
 */
public class JsonDiffToolv3 {

	/**
	 * compare json files and store the differences result
	 * driving method to actual comparison methods
	 * 
	 * @param leftMap
	 * @param rightMap
	 * @param outputFileName
	 * @return 
	 */
	public static void compareJsonsAndStoreDiffs(Map<String,Object> leftMap,Map<String,Object> rightMap,String outputFileName) {
		BufferedWriter bw = null;

		try {			
			// String timestamp = new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
			bw = new BufferedWriter(new FileWriter(outputFileName));			

			// create output objects
			JSONObjectOrdered outputJson = new JSONObjectOrdered();
			JSONObjectOrdered additionsJson = new JSONObjectOrdered();
			JSONObjectOrdered modificationsJson = new JSONObjectOrdered();
			JSONArray deletionsArray = new JSONArray();

			// leftMap keys iterator
			Iterator itr = leftMap.keySet().iterator();

			// process one entry from left, right at same time
			// if keys equal, compare value or content
			// if left key not in right, add to deletions
			// if right key not in left, add to additions
			for(String rightTopLevelKey : rightMap.keySet()) {
				String leftTopLevelKey = null;
				// get next left top key
				if(itr.hasNext()) {
					leftTopLevelKey = (String)itr.next();
				}

				// for output to be in alphabetical order, if left key comes first, process left then right keys
				if((leftTopLevelKey != null) && (leftTopLevelKey.compareTo(rightTopLevelKey) < 0)){					
					// check, top left json keys missing in right json - add to deletions
					if(leftTopLevelKey != null) {
						if(!rightMap.containsKey(leftTopLevelKey)) {
							deletionsArray.add(leftTopLevelKey);
						}
					}

					// top right key not found in left - add to additions
					if(!leftMap.containsKey(rightTopLevelKey)) {
						additionsJson.put(rightTopLevelKey, rightMap.get(rightTopLevelKey));
					}
					// top right key found in left, compare and find diffs
					else {					
						compareJsonEntriesAndFindDiffs(leftMap,rightMap,rightTopLevelKey,additionsJson,modificationsJson,deletionsArray);
					}					
				}
				// for output to be in alphabetical order, if right key comes first or both equal, process right then left keys
				else if((leftTopLevelKey != null) && (leftTopLevelKey.compareTo(rightTopLevelKey) >= 0)){					
					// top right key not found in left - add to additions
					if(!leftMap.containsKey(rightTopLevelKey)) {
						additionsJson.put(rightTopLevelKey, rightMap.get(rightTopLevelKey));
					}
					// top right key found in left, compare and find diffs
					else {					
						compareJsonEntriesAndFindDiffs(leftMap,rightMap,rightTopLevelKey,additionsJson,modificationsJson,deletionsArray);
					}

					// check, top left json keys missing in right json - add to deletions
					if(leftTopLevelKey != null) {
						if(!rightMap.containsKey(leftTopLevelKey)) {
							deletionsArray.add(leftTopLevelKey);
						}
					}					
				}								
			}

			// check, leftover top left json keys missing in right json - add to deletions
			while(itr.hasNext()) {
				String leftTopLevelKey = (String)itr.next();
				if(!rightMap.containsKey(leftTopLevelKey)) {
					deletionsArray.add(leftTopLevelKey);
				}
			}	

			// add result parts to final result object
			outputJson.put("additions", additionsJson);
			outputJson.put("modifications", modificationsJson);
			outputJson.put("deletions", deletionsArray);

			// write formatted json output to result file
			String unformattedJsonString = outputJson.toJSONString();
			bw.write(JsonUtil.prettyPrintJSON(unformattedJsonString));
			bw.flush();  //flush the buffer, write to disk

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// release resources
			try {
				if(bw != null)
					bw.close();
			}catch (Exception e) {
				e.printStackTrace();
			}			
		}		
	}


	/**
	 * compare jsons top level entries and find diffs
	 * this module handles comparison of only java literals
	 * literals - String, Integer, Number, Float, Double, Boolean, Character
	 * 
	 * @param leftMap
	 * @param rightMap
	 * @param rightTopLevelKey
	 * @param additionsJson
	 * @param modificationsJson
	 * @param deletionsArray
	 * @return 
	 */
	public static void compareJsonEntriesAndFindDiffs(Map<String,Object> leftMap,Map<String,Object> rightMap,String rightTopLevelKey,JSONObjectOrdered additionsJson,JSONObjectOrdered modificationsJson,JSONArray deletionsArray) {
		Object leftValue,rightValue;
		String leftValueType,rightValueType;

		// get current pair value
		leftValue = leftMap.get(rightTopLevelKey);
		rightValue = rightMap.get(rightTopLevelKey);

		// know the data types of left & right values
		leftValueType = getValueType(leftValue);
		rightValueType = getValueType(rightValue);

		// left, right values type mismatch - add to modifications
		if(!leftValueType.equals(rightValueType)) {
			modificationsJson.put(rightTopLevelKey, rightValue);
		}
		// left, right values type matched, check values content
		else {
			// literals - category type 3 can be checked directly
			if(checkIsLiteral(rightValueType)) {			
				// values content mismatch - add to modifications
				if(!leftValue.equals(rightValue)) {
					modificationsJson.put(rightTopLevelKey, rightValue);
				}					
			}else if(rightValueType.equals("Collection")) {
				// check both left, right collections or arrays - category type 2
				compareJsonArrayAndFindDiffs(leftMap,rightMap,rightTopLevelKey,"",additionsJson,modificationsJson,deletionsArray);
			}else if(rightValueType.equals("Map")) {
				// check both left, right json objects or maps - category type 1
				compareJsonObjectTreeAndFindDiffs(leftMap,rightMap,rightTopLevelKey,"",additionsJson,modificationsJson,deletionsArray);
			}
		}
	}


	/**
	 * check json value is java literal or not
	 * 
	 * @param type
	 * @return 
	 */
	private static boolean checkIsLiteral(String type) {
		if(type.equals("Integer") || type.equals("Number") || type.equals("Float") 
				|| type.equals("Double") || type.equals("Boolean") || type.equals("Character") || type.equals("String")) {
			return true;
		}
		return false;
	}



	/**
	 * compare jsons entries and finds diffs
	 * this module handles comparison of json array
	 * json array is equivalent to java collection,list
	 * as of now, we're not handling comparison of nested collection objects
	 * ex: list inside list, not handling this
	 * 
	 * @param leftMap
	 * @param rightMap
	 * @param rightTopLevelKey
	 * @param keyPrefix
	 * @param additionsJson
	 * @param modificationsJson
	 * @param deletionsArray
	 * @return 
	 */
	public static void compareJsonArrayAndFindDiffs(Map<String,Object> leftMap,Map<String,Object> rightMap,String rightTopLevelKey,String keyPrefix,JSONObjectOrdered additionsJson,JSONObjectOrdered modificationsJson,JSONArray deletionsArray) {
		int i;
		boolean flag;
		String leftValueType,rightValueType;
		List<Object> leftList,rightList;
		StringBuilder sbKey = new StringBuilder(keyPrefix);

		// maintain result key with proper notation
		if(!keyPrefix.isEmpty()) {
			sbKey.append(".");
		}
		sbKey.append(rightTopLevelKey);

		// get current pair left, right values - arrays or lists
		leftList = (List<Object>)leftMap.get(rightTopLevelKey);
		rightList = (List<Object>)rightMap.get(rightTopLevelKey);
		i=0;

		// step1: entries present in right list but missing in left list
		// these entries to be added to (also missing from) left list, goes to additions
		for(Object rightValue : rightList) {
			flag = false;
			for(Object leftValue : leftList) { 
				// know the data types of left & right values
				leftValueType = getValueType(leftValue);
				rightValueType = getValueType(rightValue);

				// values type matched, check values content
				if(leftValueType.equals(rightValueType)) {
					if(checkIsLiteral(rightValueType)) {
						// add to modifications only if present in right and missing in left 
						if(leftValue.equals(rightValue)) {
							flag = true;  // means, present in both, don't add to modifications
							break;
						}		
					}else if(rightValueType.equals("Collection")) {						
						// as of now, nested arrays we're not considering
						// array can be part of map, but array inside array. not handling
					}					
				}				
			}
			// present in right list but missing in left list, add to additions
			if(flag == false) {				
				String key = sbKey.toString()+"."+i;  // maintain res key proper notation
				additionsJson.put(key, rightValue);
			}
			i++;
		}

		i=0; // keep track of left list value index

		// step2: entries present in left list but missing in right list
		// these are extra entries in left list, goes to deletions
		for(Object leftValue : leftList) {
			flag = false;
			for(Object rightValue : rightList) { 
				// know the data types of left & right values
				leftValueType = getValueType(leftValue);
				rightValueType = getValueType(rightValue);

				// values type matched, check values contents
				if(leftValueType.equals(rightValueType)) {					
					if(checkIsLiteral(rightValueType)) {
						// add to deletions only if present in left and missing in right 
						if(leftValue.equals(rightValue)) { 
							flag = true;	// means, present in both, don't add to deletions
							break;
						}					
					}else if(rightValueType.equals("Collection")) {						
						// as of now, nested arrays we're not considering
						// array can be part of map, but array inside array. not handling
					}					
				}				
			}

			// for deletions, value would present in left list but not in right list
			if(flag == false) {  
				// extra contents in left list, add to deletions
				String key = sbKey.toString()+"."+i;	// maintain res key proper notation
				deletionsArray.add(key); 
			}
			i++;
		}		
	}


	/**
	 * compare jsons entries and finds diffs
	 * this module handles comparison of json objects
	 * json object is equivalent to java maps
	 * we're also handling nested maps, list inside map here
	 * do recur for nested map objects
	 * 
	 * @param leftMap
	 * @param rightMap
	 * @param rightTopLevelKey
	 * @param keyPrefix
	 * @param additionsJson
	 * @param modificationsJson
	 * @param deletionsArray
	 * @return 
	 */
	public static void compareJsonObjectTreeAndFindDiffs(Map<String,Object> leftMap,Map<String,Object> rightMap,String rightTopLevelKey,String keyPrefix,JSONObjectOrdered additionsJson,JSONObjectOrdered modificationsJson,JSONArray deletionsArray) {
		Map<String,Object> leftValueMap,rightValueMap;
		Object leftValue,rightValue;
		String leftValueType,rightValueType;
		StringBuilder sbKey = new StringBuilder(keyPrefix);

		// get current pair left,right value
		leftValueMap = (Map<String,Object>)leftMap.get(rightTopLevelKey);
		rightValueMap = (Map<String,Object>)rightMap.get(rightTopLevelKey);

		// maintain result key with proper notation
		if(!keyPrefix.isEmpty()) {
			sbKey.append(".");
		}
		sbKey.append(rightTopLevelKey);

		// traverse all entries of right map and compare with left map entries
		for(String entryKey : rightValueMap.keySet()) {			
			String key =  sbKey.toString()+"."+entryKey;

			// if entry is missing in left - add to additions
			if(!leftValueMap.containsKey(entryKey)) {
				additionsJson.put(key, rightValueMap.get(entryKey));
			}
			// entry is presnt in both left, right maps
			else {
				leftValue =  leftValueMap.get(entryKey);
				rightValue = rightValueMap.get(entryKey);

				// know the data types of left & right values
				leftValueType = getValueType(leftValue);
				rightValueType = getValueType(rightValue);

				// 3 categories of value types
				// 1. Map  2. Collection or Array  3. Literal - String, Integer, Number, Float, Double, Boolean
				// 1 & 2 category types to be handled with care
				// 3 category type can be checked directly

				// values type mismatch - add to modifications
				if(!leftValueType.equals(rightValueType)) {
					modificationsJson.put(key, rightValue);
				}
				// both left, right values type matched, check values content
				else {
					if(checkIsLiteral(rightValueType)) {
						// values content mismatch - add to modifications
						if(!leftValue.equals(rightValue)) {
							modificationsJson.put(key, rightValue);
						}					
					}else if(rightValueType.equals("Collection")) {
						// compare both left, right arrays
						compareJsonArrayAndFindDiffs(leftValueMap,rightValueMap,entryKey,sbKey.toString(),additionsJson,modificationsJson,deletionsArray);
					}else if(rightValueType.equals("Map")) {
						// recur for nested map object and repeat process
						compareJsonObjectTreeAndFindDiffs(leftValueMap,rightValueMap,entryKey,sbKey.toString(),additionsJson,modificationsJson,deletionsArray);
					}
				}
			} // else
		} // for

		// check left value map entries missing in right value map - add to deletions
		for(String entryKey : leftValueMap.keySet()) {
			String key =  sbKey.toString()+"."+entryKey;
			if(!rightValueMap.containsKey(entryKey)) {
				deletionsArray.add(key);
			}
		} // for

	}


	/**
	 * get json entry value java data type
	 * 
	 * @param value
	 * @return 
	 */
	public static String getValueType(Object value) {

		if(value instanceof String){		
			return "String";
		}

		if(value instanceof Integer){
			return "Integer";
		}

		if(value instanceof Float){
			return "Float";
		}

		if(value instanceof Double){
			return "Double";
		}					

		if(value instanceof Number){
			return "Number";
		}

		if(value instanceof Boolean){
			return "Boolean";
		}

		if(value instanceof Character){
			return "Character";
		}

		if(value instanceof Map){
			return "Map";
		}

		if(value instanceof Collection){
			return "Collection";
		}

		return "Object";
	}


	/**
	 * print json entry value java data type
	 * as of now, we're not using this method
	 * 
	 * @param obj
	 * @return 
	 */
	public static void printJsonValueType(Object obj) {
		//public static void printJsonValueType(JSONObjectOrdered rightJson,List<String> rightKeyList) {
		LinkedList<Object> list = (LinkedList<Object>)obj;
		Object value;
		for(Object key:list) {
			//value = (Object)map.get(key);
			value = (Object)key;

			if(value instanceof String){		
				System.out.println(key+" - value is String type");
			}

			if(value instanceof Integer){
				System.out.println(key+" - value is Integer type");
			}

			if(value instanceof Float){
				System.out.println(key+" - value is Float type");
			}

			if(value instanceof Double){
				System.out.println(key+" - value is Double type");
			}					

			if(value instanceof Number){
				System.out.println(key+" - value is Number type");
			}

			if(value instanceof Boolean){
				System.out.println(key+" - value is Boolean type");
			}

			if(value instanceof Map){
				System.out.println(key+" - value is Map type");
			}

			if(value instanceof Collection){
				System.out.println(key+" - value is Collection type");
			}

			if(value instanceof byte[]){
				System.out.println(key+" - value is byte[] type");
			}

			if(value instanceof short[]){
				System.out.println(key+" - value is short[] type");
			}

			if(value instanceof int[]){
				System.out.println(key+" - value is int[] type");
			}

			if(value instanceof long[]){
				System.out.println(key+" - value is long[] type");
			}

			if(value instanceof float[]){
				System.out.println(key+" - value is float[] type");
			}

			if(value instanceof double[]){
				System.out.println(key+" - value is double[] type");
			}

			if(value instanceof boolean[]){
				System.out.println(key+" - value is boolean[] type");
			}

			if(value instanceof char[]){
				System.out.println(key+" - value is char[] type");
			}

			if((value instanceof JSONAware)){
				System.out.println(key+" - value is JSONAware type");
			}

			if((value instanceof JSONStreamAware)){
				System.out.println(key+" - value is JSONStreamAware type");
			}

			if(value instanceof Object[]){
				System.out.println(key+" - value is Object[] type");
			}			

		}

	}

}


