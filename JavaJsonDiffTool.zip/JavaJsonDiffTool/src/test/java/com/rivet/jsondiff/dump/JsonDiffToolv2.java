package com.rivet.jsondiff.dump;

import com.rivet.jsondiff.util.JsonUtil;

import java.util.Map;
import java.util.List;
import java.util.LinkedList;
import java.util.Collection;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONAware;
import org.json.simple.JSONObjectOrdered;
import org.json.simple.JSONStreamAware;


// this class contains actual methods 
// which handles json files comparison & finding diffs logic   
// each json object is represented as a key,value pair
// for making things easier, we're converting input json files into ordered maps
// json object is equivalent to java map and json array is equivalent to java collection,list
// all json keys are string types
// json value types are of 3 categories 
// 1. Map  
// 2. Collection or list or Array  
// 3. Literal - String, Integer, Number, Float, Double, Boolean, Character
// 1 & 2 category types to be handled with care due to nested structure
// as of now, nested lists, we're not handling  ex: list inside list
// we're also handling list inside maps & nested maps  ex: map inside map

// as per the provided example output result, considering right json file as base
// and comparing with left json file for differences
public class JsonDiffToolv2 {

	// compare json files and store the differences result
	// public static void compareJsonsAndStoreDiffs(JSONObject leftJson,JSONObject rightJson,List<String> leftKeyList,List<String> rightKeyList) {
	public static void compareJsonsAndStoreDiffs(Map<String,Object> leftMap,Map<String,Object> rightMap,List<String> leftKeyList,List<String> rightKeyList,String outputFileName) {
		BufferedWriter bw = null;

		try {			
			// String timestamp = new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
			bw = new BufferedWriter(new FileWriter(outputFileName));			

			// create output objects
			JSONObjectOrdered outputJson = new JSONObjectOrdered();
			JSONObjectOrdered additionsJson = new JSONObjectOrdered();
			JSONObjectOrdered modificationsJson = new JSONObjectOrdered();
			JSONArray deletionsArray = new JSONArray();

			// compare jsons and find differences
			// take json entry from right json and compare with left json
			for(String rightTopLevelKey:rightKeyList) {

				// additions - present in right missing in left
				if(!leftMap.containsKey(rightTopLevelKey)) {
					additionsJson.put(rightTopLevelKey, rightMap.get(rightTopLevelKey));
				}
				else {										
					// top level key found in both left & right jsons, find diffs
					compareJsonEntriesAndFindDiffs(leftMap,rightMap,rightTopLevelKey,additionsJson,modificationsJson,deletionsArray);
				}				
			}

			// add result parts to final result object
			outputJson.put("additions", additionsJson);
			outputJson.put("modifications", modificationsJson);
			outputJson.put("deletions", deletionsArray);

			// write formatted json output to result file
			String unformattedJsonString = outputJson.toJSONString();
			bw.write(JsonUtil.prettyPrintJSON(unformattedJsonString));
			bw.flush();


			// print right json
			// printJsonValueType(rightJson,rightKeyList);

			/*	
			//test			
			JSONObjectOrdered obj = new JSONObjectOrdered();			
			JSONObjectOrdered map1 = new JSONObjectOrdered();
			map1.put("1one", "1");
			map1.put("2two", 2);
			map1.put("3three", "3");
			map1.put("4zero", 0);			
			JSONArray jarr1 = new JSONArray();
			jarr1.add("1"); jarr1.add("2"); jarr1.add(3);
			jarr1.add("4"); jarr1.add(5.123);

			obj.put("Map 1", map1);
			obj.put("Array 1", jarr1);
			obj.put("String 1", "Str");
			obj.put("Int 1", 123);
			obj.put("Float 1", 10.157);

			List<String> objKeyList = new ArrayList<String>();
			objKeyList.add("Map 1");
			objKeyList.add("Array 1");
			objKeyList.add("String 1");
			objKeyList.add("Int 1");
			objKeyList.add("Float 1");			
			printJsonValueType(obj,objKeyList);

			/*
			System.out.println("leftJson: "+leftJson);
			System.out.println("rightJson: "+rightJson);
			System.out.println("leftList: "+leftList);
			System.out.println("rightList: "+rightList);
			System.out.println("obj: "+obj);

			//obj.writeJSONString(bw);
			//leftJson.writeJSONString(bw);
			//fw.write(obj.toJSONString());

			String unformattedJsonString = obj.toJSONString();
			bw.write(JsonUtil.prettyPrintJSON(unformattedJsonString));
			bw.flush();

			output:
			leftJson: {"bar1":2,"foo11":{"bar":["bat","baz"]},"test1":{"a":1}}
			rightJson: {"bar2":3,"test2":{"a":2},"foo22":{"bar":["baz"]}}
			leftList: [foo11, test1, bar1]
			rightList: [foo22, test2, bar2]
			obj: {"Map 1":{"1one":"1","2two":2,"3three":"3","4zero":0},"Array 1":["1","2",3,"4",5.123],"String 1":"Str","Int 1":123,"Float 1":10.157}
			total time taken: 47ms

			leftJson: {"bar1":2,"foo11":{"bar":["bat","baz"]},"test1":{"a":1}}
			rightJson: {"bar2":3,"test2":{"a":2},"foo22":{"bar":["baz"]}}
			leftList: [foo11, test1, bar1]
			rightList: [foo22, test2, bar2]
			obj: {"Map 1":{"1one":"1","2two":2,"3three":"3","4zero":0},"Array 1":["1","2",3,"4",5.123],"String 1":"Str","Int 1":123,"Float 1":10.157}
			total time taken: 51ms

			 */


		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// release resources
			try {
				if(bw != null)
					bw.close();
			}catch (Exception e) {
				e.printStackTrace();
			}			
		}		
	}

	// compare jsons top level entries and find diffs
	// this module handles comparison of only java literals
	// literals - String, Integer, Number, Float, Double, Boolean, Character
	public static void compareJsonEntriesAndFindDiffs(Map<String,Object> leftMap,Map<String,Object> rightMap,String rightTopLevelKey,JSONObjectOrdered additionsJson,JSONObjectOrdered modificationsJson,JSONArray deletionsArray) {
		System.out.println("rightTopLevelKey: "+rightTopLevelKey);
		Object leftValue,rightValue;
		String leftValueType,rightValueType;

		leftValue = leftMap.get(rightTopLevelKey);
		rightValue = rightMap.get(rightTopLevelKey);

		// know the data types of left & right values
		leftValueType = getValueType(leftValue);
		rightValueType = getValueType(rightValue);

		// left, right values type mismatch - add to modifications
		if(!leftValueType.equals(rightValueType)) {
			modificationsJson.put(rightTopLevelKey, rightValue);
		}
		// left, right values type matched, check values content
		else {
			// literals - category type 3 can be checked directly
			if(rightValueType.equals("Integer") || rightValueType.equals("Number") || rightValueType.equals("Float") || rightValueType.equals("Double") || rightValueType.equals("Boolean") || rightValueType.equals("Character")) {
				// values content mismatch - add to modifications
				if(leftValue != rightValue) {
					modificationsJson.put(rightTopLevelKey, rightValue);
				}
			}else if(rightValueType.equals("String")) {
				// values content mismatch - add to modifications
				if(!leftValue.equals(rightValue)) {
					modificationsJson.put(rightTopLevelKey, rightValue);
				}					
			}else if(rightValueType.equals("Collection")) {
				// check both left, right collections or arrays - category type 2
				compareJsonArrayAndFindDiffs(leftMap,rightMap,rightTopLevelKey,"",additionsJson,modificationsJson,deletionsArray);
			}else if(rightValueType.equals("Map")) {
				// check both left, right json objects or maps - category type 1
				compareJsonObjectTreeAndFindDiffs(leftMap,rightMap,rightTopLevelKey,"",additionsJson,modificationsJson,deletionsArray);
			}
		}
	}


	// compare jsons entries and finds diffs
	// this module handles comparison of json array
	// json array is equivalent to java collection,list 
	// as of now, we're not handling comparison of nested collection objects
	// ex: list inside list, not handling this
	// list inside map works fine
	public static void compareJsonArrayAndFindDiffs(Map<String,Object> leftMap,Map<String,Object> rightMap,String rightTopLevelKey,String keyPrefix,JSONObjectOrdered additionsJson,JSONObjectOrdered modificationsJson,JSONArray deletionsArray) {
		int i;
		boolean flag;
		String leftValueType,rightValueType;
		List<Object> leftList,rightList;
		StringBuilder sbKey = new StringBuilder(keyPrefix);

		// if current entry is part of nested object
		if(!keyPrefix.isEmpty()) {
			sbKey.append(".");
		}

		// get left, right arrays or lists
		leftList = (List<Object>)leftMap.get(rightTopLevelKey);
		rightList = (List<Object>)rightMap.get(rightTopLevelKey);

		// maintain key name with proper (dot) notation
		sbKey.append(rightTopLevelKey);
		i=0;

		// step1: entries present in right list but missing in left list
		// these entries to be added to (also missing from) left list, goes to additions
		for(Object rightValue : rightList) {
			flag = false;
			for(Object leftValue : leftList) { 
				// know the data types of left & right values
				leftValueType = getValueType(leftValue);
				rightValueType = getValueType(rightValue);

				// values type matched, check values content
				if(leftValueType.equals(rightValueType)) {
					String key = sbKey.toString()+"."+i;
					if(rightValueType.equals("Integer") || rightValueType.equals("Number") || rightValueType.equals("Float") || rightValueType.equals("Double") || rightValueType.equals("Boolean") || rightValueType.equals("Character")) {
						// values content mismatch - add to modifications
						if(leftValue == rightValue) {
							flag = true;
							break;
						}
					}else if(rightValueType.equals("String")) {
						// values content mismatch - add to modifications
						if(leftValue.equals(rightValue)) {
							flag = true;
							break;

						}					
					}else if(rightValueType.equals("Collection")) {						
						// as of now, nested arrays we're not considering
						// array can be part of map, but array inside array. not handling
					}					
				}				
			}
			if(flag == false) {
				// present in right list but missing in left list, add to additions
				String key = sbKey.toString()+"."+i;
				additionsJson.put(key, rightValue);
			}
			i++;
		}

		i=0; // keep track of left list value index

		// step2: entries present in left list but missing in right list
		// these are extra entries in left list, goes to deletions
		for(Object leftValue : leftList) {
			flag = false;
			for(Object rightValue : rightList) { 
				// know the data types of left & right values
				leftValueType = getValueType(leftValue);
				rightValueType = getValueType(rightValue);

				// values type matched, check values contents
				if(leftValueType.equals(rightValueType)) {					
					if(rightValueType.equals("Integer") || rightValueType.equals("Number") || rightValueType.equals("Float") || rightValueType.equals("Double") || rightValueType.equals("Boolean") || rightValueType.equals("Character")) {
						// values content mismatch - add to modifications
						if(leftValue == rightValue) {
							flag = true;
							break;
						}
					}else if(rightValueType.equals("String")) {
						// values content mismatch - add to modifications
						if(leftValue.equals(rightValue)) {
							flag = true;
							break;
						}					
					}else if(rightValueType.equals("Collection")) {						
						// as of now, nested arrays we're not considering
						// array can be part of map, but array inside array. not handling
					}					
				}				
			}

			// for deletions, value would present in left list but not in right list
			if(flag == false) {  
				// extra contents in left list, add to deletions
				String key = sbKey.toString()+"."+i;
				deletionsArray.add(key); // rightValue
			}
			i++;
		}


		/*
		// step 3: take right list entries, compare with left list entries, 
		// these are mismatch entries, goes to modifications
		for(Object rightValue : rightList) {
			Iterator it=leftList.iterator();
			while (it.hasNext()){
				flag = false;
				Object leftValue = (Object)it.next(); 
				// know the data types of left & right values
				leftValueType = getValueType(leftValue);
				rightValueType = getValueType(rightValue);

				// values type matched, check values contents
				if(leftValueType.equals(rightValueType)) {
					String key = sbKey.toString()+"."+i;
					if(rightValueType.equals("Integer") || rightValueType.equals("Number") || rightValueType.equals("Float") || rightValueType.equals("Double") || rightValueType.equals("Boolean") || rightValueType.equals("Character")) {
						// values content mismatch - add to modifications
						if(leftValue != rightValue) {
							flag = true;
						}
					}else if(rightValueType.equals("String")) {
						// values content mismatch - add to modifications
						if(!leftValue.equals(rightValue)) {
							flag = true;

						}					
					}else if(rightValueType.equals("Collection")) {
						// check both left, right arrays
						//compareObjectTreeAndFindDiffs(leftValue,rightValue,rightTopLevelKey,"",additionsJson,modificationsJson,deletionsArray);
						// as of now, nested arrays we're not considering
						// array can be part of map, but array inside array. not handling
					}

					if(flag) {
						// contents mismatch, add to modifications
						modificationsJson.put(key, rightValue);
						// visited values, remove from left list
						it.remove();
					}					
				}				
			}
			i++;  // right list value index
		}

		 */
	}


	// compare jsons entries and finds diffs
	// this module handles comparison of json objects
	// json object is equivalent to java maps
	// we're also handling nested maps, list inside map here
	// do recur for nested map objects
	public static void compareJsonObjectTreeAndFindDiffs(Map<String,Object> leftMap,Map<String,Object> rightMap,String rightTopLevelKey,String keyPrefix,JSONObjectOrdered additionsJson,JSONObjectOrdered modificationsJson,JSONArray deletionsArray) {
		Map<String,Object> leftValueMap,rightValueMap;
		Object leftValue,rightValue;
		String leftValueType,rightValueType;
		StringBuilder sbKey = new StringBuilder(keyPrefix);

		leftValueMap = (Map<String,Object>)leftMap.get(rightTopLevelKey);
		rightValueMap = (Map<String,Object>)rightMap.get(rightTopLevelKey);

		// for nested objects, maintain result key with proper notation
		if(!keyPrefix.isEmpty()) {
			sbKey.append(".");
		}
		sbKey.append(rightTopLevelKey);

		// traverse all entries of right map and compare with left map entries
		for(String entryKey : rightValueMap.keySet()) {			
			String key =  sbKey.toString()+"."+entryKey;

			leftValue =  leftValueMap.get(entryKey);
			rightValue = rightValueMap.get(entryKey);

			// know the data types of left & right values
			leftValueType = getValueType(leftValue);
			rightValueType = getValueType(rightValue);

			// 3 categories of value types
			// 1. Map  2. Collection or Array  3. Literal - String, Integer, Number, Float, Double, Boolean
			// 1 & 2 category types to be handled with care
			// 3 category type can be checked directly

			// values type mismatch - add to modifications
			if(!leftValueType.equals(rightValueType)) {
				modificationsJson.put(key, rightValue);
			}
			// both left, right values type matched, check values content
			else {
				if(rightValueType.equals("Integer") || rightValueType.equals("Number") || rightValueType.equals("Float") || rightValueType.equals("Double") || rightValueType.equals("Boolean") || rightValueType.equals("Character")) {
					// values content mismatch - add to modifications
					if(leftValue != rightValue) {
						modificationsJson.put(key, rightValue);
					}
				}else if(rightValueType.equals("String")) {
					// values content mismatch - add to modifications
					if(!leftValue.equals(rightValue)) {
						modificationsJson.put(key, rightValue);
					}					
				}else if(rightValueType.equals("Collection")) {
					// compare both left, right arrays
					compareJsonArrayAndFindDiffs(leftValueMap,rightValueMap,entryKey,sbKey.toString(),additionsJson,modificationsJson,deletionsArray);
				}else if(rightValueType.equals("Map")) {
					// recur for nested map object and do compare
					compareJsonObjectTreeAndFindDiffs(leftValueMap,rightValueMap,entryKey,sbKey.toString(),additionsJson,modificationsJson,deletionsArray);
				}
			}
		}

	}


	// get json entry value java data type
	public static String getValueType(Object value) {

		if(value instanceof String){		
			return "String";
		}

		if(value instanceof Integer){
			return "Integer";
		}

		if(value instanceof Float){
			return "Float";
		}

		if(value instanceof Double){
			return "Double";
		}					

		if(value instanceof Number){
			return "Number";
		}

		if(value instanceof Boolean){
			return "Boolean";
		}

		if(value instanceof Character){
			return "Character";
		}

		if(value instanceof Map){
			return "Map";
		}

		if(value instanceof Collection){
			return "Collection";
		}

		return "Object";
	}

	// print json entry value java data type
	public static void printJsonValueType(Object obj) {
		//public static void printJsonValueType(JSONObjectOrdered rightJson,List<String> rightKeyList) {
		LinkedList<Object> list = (LinkedList<Object>)obj;
		Object value;
		for(Object key:list) {
			//value = (Object)map.get(key);
			value = (Object)key;

			if(value instanceof String){		
				System.out.println(key+" - value is String type");
			}

			if(value instanceof Integer){
				System.out.println(key+" - value is Integer type");
			}

			if(value instanceof Float){
				System.out.println(key+" - value is Float type");
			}

			if(value instanceof Double){
				System.out.println(key+" - value is Double type");
			}					

			if(value instanceof Number){
				System.out.println(key+" - value is Number type");
			}

			if(value instanceof Boolean){
				System.out.println(key+" - value is Boolean type");
			}

			if(value instanceof Map){
				System.out.println(key+" - value is Map type");
			}

			if(value instanceof Collection){
				System.out.println(key+" - value is Collection type");
			}

			if(value instanceof byte[]){
				System.out.println(key+" - value is byte[] type");
			}

			if(value instanceof short[]){
				System.out.println(key+" - value is short[] type");
			}

			if(value instanceof int[]){
				System.out.println(key+" - value is int[] type");
			}

			if(value instanceof long[]){
				System.out.println(key+" - value is long[] type");
			}

			if(value instanceof float[]){
				System.out.println(key+" - value is float[] type");
			}

			if(value instanceof double[]){
				System.out.println(key+" - value is double[] type");
			}

			if(value instanceof boolean[]){
				System.out.println(key+" - value is boolean[] type");
			}

			if(value instanceof char[]){
				System.out.println(key+" - value is char[] type");
			}

			if((value instanceof JSONAware)){
				System.out.println(key+" - value is JSONAware type");
			}

			if((value instanceof JSONStreamAware)){
				System.out.println(key+" - value is JSONStreamAware type");
			}

			if(value instanceof Object[]){
				System.out.println(key+" - value is Object[] type");
			}			

		}

	}

}


