package com.rivet.jsondiff.dump;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.json.simple.parser.ContainerFactory;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


/**
 * this is the class where execution starts and 
 * below pre-processing tasks will be done
 * 1. load configuration properties
 * 2. load or parse input json files into ordered map 
 */
public class MainAppv2 {
	
	/**
	 * the starting point of the application
	 * @param args 
	 */
	public static void main(String[] args) {
		Properties configprop = null;
		BufferedReader br1 = null, br2 = null;

		try {			
			String configFileName,leftFileName,rightFileName,outputFileName;			
			Map<String,Object> leftMap,rightMap;
			
			System.out.println("execution started");
			
			//configFileName = "config.properties";
			configprop = new Properties();
			configFileName = "C:\\Users\\venky\\Desktop\\rivetlabs\\json-diff\\config.properties";

			// load configuration properties
			configprop.load(new FileReader(configFileName)); 

			// get input & output file names from configuration properties
			leftFileName = configprop.getProperty("LEFT_FILE_NAME").trim();
			rightFileName = configprop.getProperty("RIGHT_FILE_NAME").trim();
			outputFileName = configprop.getProperty("OUTPUT_FILE_NAME").trim();
			long start = System.currentTimeMillis();

			// Json parser to parse a Json file 
			JSONParser jsonParser = new JSONParser();

			// parse input json files in their original order  
			ContainerFactory containerFactory = new ContainerFactory() {
				@Override
				public Map createObjectContainer() {
					return new LinkedHashMap<>();
				}
				@Override
				public List creatArrayContainer() {
					return new LinkedList<>();
				}
			};

			// faster access or read of input json files
			br1 = new BufferedReader(new FileReader(leftFileName));
			br2 = new BufferedReader(new FileReader(rightFileName));

			// ordered maps of input json files 
			leftMap = (Map<String,Object>)jsonParser.parse(br1, containerFactory);
			rightMap = (Map<String,Object>)jsonParser.parse(br2, containerFactory);		
			
			// compare json files and store the differences result
			JsonDiffToolv3.compareJsonsAndStoreDiffs(leftMap,rightMap,outputFileName);

			System.out.println("results are stored in file: "+outputFileName);
			System.out.println("total time taken: " + (System.currentTimeMillis() - start) +"ms");			
			System.out.println("execution completed");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// release resources
			try {
				if(configprop != null)
					configprop.clear();
				if(br1 != null)
					br1.close();
				if(br2 != null)
					br2.close();
			}catch (Exception e) {
				e.printStackTrace();
			}			
		}
	}
}


