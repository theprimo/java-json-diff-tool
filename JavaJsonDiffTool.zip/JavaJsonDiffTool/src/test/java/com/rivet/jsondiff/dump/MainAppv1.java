package com.rivet.jsondiff.dump;

import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONObjectOrdered;
import org.json.simple.parser.ContainerFactory;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// this is the class where our process starts
// in this we're performing below tasks 
// 1. load configuration properties
// 2. load or parse input json files into ordered map

// as per the provided example output result, considering right json file as base
// and comparing with left json file for differences

public class MainAppv1 {

	public static void main(String[] args) {
		Properties configprop = null;
		BufferedReader br1 = null, br2 = null;

		try {			
			String leftFileName,rightFileName,configFileName,outputFileName;			
			Map<String,Object> leftMap,rightMap;
			List<String> leftKeyList,rightKeyList;
			//JSONObject leftJson,rightJson;

			//configFileName = "config.properties";
			configprop = new Properties();
			configFileName = "C:\\Users\\venky\\Desktop\\rivetlabs\\json-diff\\config.properties";

			// load configuration properties
			configprop.load(new FileReader(configFileName)); 

			// load input json files absolute paths from config
			leftFileName = configprop.getProperty("LEFT_FILE_NAME").trim();
			rightFileName = configprop.getProperty("RIGHT_FILE_NAME").trim();
			outputFileName = configprop.getProperty("OUTPUT_FILE_NAME").trim();
			long start = System.currentTimeMillis();

			// Json parser to parse a Json file 
			JSONParser jsonParser = new JSONParser();

			// parse input json files in their original order  
			ContainerFactory containerFactory = new ContainerFactory() {
				@Override
				public Map createObjectContainer() {
					return new LinkedHashMap<>();
				}
				@Override
				public List creatArrayContainer() {
					return new LinkedList<>();
				}
			};

			// faster access or read of input json files
			br1 = new BufferedReader(new FileReader(leftFileName));
			br2 = new BufferedReader(new FileReader(rightFileName));

			// ordered maps of input json files 
			leftMap = (Map<String,Object>)jsonParser.parse(br1, containerFactory);
			rightMap = (Map<String,Object>)jsonParser.parse(br2, containerFactory);

			// store top level keys in lists
			leftKeyList = new ArrayList<>();
			rightKeyList = new ArrayList<>();
			leftKeyList.addAll(leftMap.keySet());
			rightKeyList.addAll(rightMap.keySet());


			// Read or Parse Left JSON file
			// Map<String,Object> map = (HashMap<String,Object>)jsonParser.parse(br1);
			//			JSONObjectOrdered jsonObjOrdered = (JSONObjectOrdered) jsonParser.parse(br1, containerFactory);
			//			System.out.println("left jsonObjOrdered: "+jsonObjOrdered);
			//			if(jsonObjOrdered != null)
			//				return;


			// test
			//JsonDiffTool.printJsonValueType(leftMap.get("Array 1"));
			//System.out.println(" ---- ");
			//JsonDiffTool.printJsonValueType(rightMap,rightKeyList);

			// save memory
			// leftMap=rightMap=null;

			// parse input json files and store in json objects
			//			br1 = new BufferedReader(new FileReader(leftFileName));
			//			br2 = new BufferedReader(new FileReader(rightFileName));
			//			leftJson = (JSONObject)jsonParser.parse(br1);  //unordered json
			//			rightJson = (JSONObject)jsonParser.parse(br2); //unordered json

			//leftJson = new JSONObject(leftMap);
			//System.out.println("leftJson: "+leftJson);
			//System.out.println("leftMap: "+leftMap);
			
			// compare json files and store the differences result
			JsonDiffToolv2.compareJsonsAndStoreDiffs(leftMap,rightMap,leftKeyList,rightKeyList,outputFileName);

			System.out.println("total time taken: " + (System.currentTimeMillis() - start) +"ms");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// release resources
			try {
				if(configprop != null)
					configprop.clear();
				if(br1 != null)
					br1.close();
				if(br2 != null)
					br2.close();
			}catch (Exception e) {
				e.printStackTrace();
			}			
		}
	}
}


